#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "highgui.h"
#include "cv.h"
#include "graph.h"
#include "mex.h"

using namespace cv;

int num_labels = 32;
int radius_mask = 31;
int biggest_num = 100000;
int big_num = 10000;

struct label_set
{
	int start_id_white;
	int start_id_black;
	int num;
	int black_num;
};
int* labels;
int* black_labels;	// delete is time-consuming, separate these from the struct.
int num_white_nodes = 0;
int num_black_nodes = 0;

void cut_T(int* B, int* T, int h, int w);
void form_labelset(label_set* set, int h, int w, int* B);

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	// ����B�� ���T_initial
	double* pB = mxGetPr(prhs[0]);
	int w = mxGetN(prhs[0]);
	int h = mxGetM(prhs[0]);
	int* B = new int[h*w];
	int* T = new int[h*w];
    
    for(int im=0;im<h;im++) 
        for(int in=0;in<w;in++) 
            B[im*w+in] = round((num_labels - 1) * pB[in*h+im]) + 1;
	////����
	cut_T(B, T, h, w);
	//// �����������
	mwSize dims[2] = { h, w };
	plhs[0] = mxCreateNumericArray(2, dims, mxDOUBLE_CLASS, mxREAL);
    double* pT = mxGetPr(plhs[0]);
    for(int im=0;im<h;im++) 
        for(int in=0;in<w;in++) 
            pT[in*h+im] = T[im*w+in];
    delete[] B;
    delete[] T;
}

void cut_T(int* B, int* T, int h, int w)
{	
	//param
	int num_pixels = w*h;

	// form label set
	label_set* set = new label_set[num_pixels];
	form_labelset(set, h, w, B);
	// build Graph
	typedef Graph<int, int, int> GraphType;
	GraphType *g = new GraphType(num_black_nodes, 4*num_black_nodes);
	label_set* cur_set;
	label_set* comp_set;
	for (int im = 0; im < h; ++im)
	{
		for (int in = 0; in < w; ++in)
		{
			cur_set = &set[im*w + in];
			// ����nodes
			int cur = 0;
			bool isblack;
			bool pre_isblack = false;
			for (int iv = 0; iv < cur_set->black_num; ++iv)
			{
				int cur_id = cur_set->start_id_black + iv;
				// �ж��Ƿ�Ϊ black node
				isblack = true;
				if (labels[cur_set->start_id_white + cur] == black_labels[cur_set->start_id_black + iv])
				{
					isblack = false;
					++cur;
				}
				g->add_node();
				// ���λ�� node ���� t
				if (iv==0)
					g->add_tweights(cur_id, 0, biggest_num);
				// ��һλΪ black node
				if (pre_isblack == true)
				{
					g->add_edge(cur_id, cur_id - 1, biggest_num, biggest_num);
				}
				// ���λ�� black node ���� s
				if (iv == cur_set->black_num - 1 && isblack == true)
				{
					g->add_tweights(cur_id, biggest_num, 0);
				}
				// �����λΪ black node, ��¼�� pre_isblack
				pre_isblack = isblack;
			}
			// ����edges
			for (int t = 0; t<4; ++t)
			{
				if (t == 0) if(im == 0)					continue; 
				else									comp_set = &set[(im - 1)*w + in];			// ��
				if (t == 1) if(im == 0 || in == 0)		continue;
				else									comp_set = &set[(im - 1)*w + in - 1];		// ����
				if (t == 2) if(in == 0)					continue;
				else									comp_set = &set[im*w + in - 1];				//��
				if (t == 3) if(im == 0 || in == w - 1)	continue;
				else									comp_set = &set[(im - 1)*w + in + 1];		//����
				int iv_cur = 0;
				int iv_cur_black = 0;
				int iv_comp = 0;
				int iv_comp_black = 0;
				int cur_flag, comp_flag; // flag=0, not exist; flag=1, white node; flag=-1, black node.
				int power = 1;
				int start_label = min(labels[cur_set->start_id_white], labels[comp_set->start_id_white]);
				while (black_labels[cur_set->start_id_black+iv_cur_black] < start_label) ++iv_cur_black;
				while (black_labels[comp_set->start_id_black+iv_comp_black] < start_label) ++iv_comp_black;
				for (int il = start_label; il <= num_labels; ++il)
				{
					//set cur flags
					if (black_labels[cur_set->start_id_black+iv_cur_black] == il)
					{
						cur_flag = -1;
						++iv_cur_black;
						if (labels[cur_set->start_id_white+iv_cur] == il)
						{
							cur_flag = 1;
							++iv_cur;
						}
					}
					else
					{
						cur_flag = 0;
					}
					//set comp flag
					if (black_labels[comp_set->start_id_black+iv_comp_black] == il)
					{
						comp_flag = -1;
						++iv_comp_black;
						if (labels[comp_set->start_id_white+iv_comp] == il)
						{
							comp_flag = 1;
							++iv_comp;
						}
					}
					else
					{
						comp_flag = 0;
					}
					// if not exist, or both black
					if ( (comp_flag == -1 && cur_flag == -1) || comp_flag == 0 || cur_flag == 0)
					{
						++power;
						continue;
					}
					else
					{
						double dist;
						if (t == 0) dist = pow(B[im*w + in] - B[(im - 1)*w + in], 2);
						if (t == 1) dist = pow(B[im*w + in] - B[(im - 1)*w + in-1], 2);
						if (t == 2) dist = pow(B[im*w + in] - B[im*w + in-1], 2);
						if (t == 3) dist = pow(B[im*w + in] - B[(im - 1)*w + in+1], 2);

						int comp_weight = big_num / max(0.1, dist);
						int label_1 = cur_set->start_id_black + iv_cur_black - 1;
						int label_2 = comp_set->start_id_black + iv_comp_black - 1;

						g->add_edge(label_1, label_2, comp_weight*power, comp_weight*power);
						power = 1;
					}
				}
			} // end, add edges on 4 directions

		}// end, in
	}// end, im

	//cut Graph
	int flow = g->maxflow();

	//form result
	for (int ip = 0; ip < num_pixels; ++ip)
	{
		label_set* cur_set = &set[ip];
		int white_num = cur_set->num;
		int black_num = cur_set->black_num;
		int start_id = cur_set->start_id_black;
		int end_id = start_id + black_num;
		if (white_num == 1)
		{
			T[ip] = labels[cur_set->start_id_white];
			continue;
		}
		for (int id = start_id + 1; id < end_id; ++id)
		{
			if (g->what_segment(id) == GraphType::SOURCE)
			{
				T[ip] = black_labels[cur_set->start_id_black + id - start_id - 1];
				break;
			}
			if (id==end_id-1)
				T[ip] = labels[cur_set->start_id_white + white_num - 1];
		}
	}

	//clear up
	delete g;
	delete[] labels;
	delete[] black_labels;
	delete[] set;
}
void form_labelset(label_set* set, int h, int w, int* B)
{
	int num_pixels = w*h;
	//initial
	label_set* cur_set;
	for (int ip = 0; ip < num_pixels; ++ip)
	{
		cur_set = &set[ip];
		cur_set->start_id_white = 0;
		cur_set->start_id_black = 0;
		cur_set->num = 0;
		cur_set->black_num = 0;
	}
	//form labels
	int sz[] = { h, w, num_labels };
	
	CvMat**  seed  = new CvMat*[num_labels];
	CvMat**  seed2 = new CvMat*[num_labels];
	for (int intensity = 1; intensity <= num_labels; ++intensity)
	{
		seed [intensity - 1] = cvCreateMat(h, w, CV_8UC1);
		seed2[intensity - 1] = cvCreateMat(h, w, CV_8UC1);
		cvZero(seed[intensity - 1]);
		for (int im = 0; im < h; ++im)
		for (int in = 0; in < w; ++in)
		if (B[im*w + in] == intensity)
			CV_MAT_ELEM(*seed[intensity - 1], uchar, im, in) = 1;

		cvDilate(seed[intensity - 1],  seed[intensity - 1],  cvCreateStructuringElementEx(radius_mask, radius_mask, radius_mask / 2, radius_mask / 2, CV_SHAPE_ELLIPSE));
		cvDilate(seed[intensity - 1], seed2[intensity - 1], cvCreateStructuringElementEx(3, 3, 1, 1, CV_SHAPE_RECT));
		
		for (int im = 0; im < h; ++im)
		{
			for (int in = 0; in < w; ++in)
			{
				cur_set = &set[im*w + in];
				if (CV_MAT_ELEM(*seed[intensity - 1], uchar, im, in) == 1 && B[im*w + in] >= intensity)
				{
					++cur_set->num;
					++cur_set->black_num;
					++num_white_nodes;
					++num_black_nodes;
					continue;
				}
				if (CV_MAT_ELEM(*seed2[intensity - 1], uchar, im, in) == 1)
				{
					++cur_set->black_num;
					++num_black_nodes;
				}
			}
		}
		
	}// end intensity loop

	int id_white = 0;
	int id_black = 0;
	labels = new int[num_white_nodes];
	black_labels = new int[num_black_nodes];
	for (int im = 0; im < h; ++im)
	{
		for (int in = 0; in < w; ++in)
		{
			cur_set = &set[im*w + in];
			cur_set->start_id_white = id_white;
			cur_set->start_id_black = id_black;
			id_white += cur_set->num;
			id_black += cur_set->black_num;
			int count = 0;
			int black_count = 0;
			for (int intensity = 1; intensity <= num_labels; ++intensity)
			{
				if (CV_MAT_ELEM(*seed[intensity - 1], uchar, im, in) == 1 && B[im*w + in] >= intensity)
				{
					labels[cur_set->start_id_white+(count++)] = intensity;
					black_labels[cur_set->start_id_black+(black_count++)] = intensity;
					continue;
				}
				if (CV_MAT_ELEM(*seed2[intensity - 1], uchar, im, in) == 1)
				{
					black_labels[cur_set->start_id_black + (black_count++)] = intensity;
					continue;
				}
			}
		}
	}
	for (int intensity = 1; intensity <= num_labels; ++intensity)
	{
		cvReleaseMat(&seed[intensity - 1]);
		cvReleaseMat(&seed2[intensity - 1]);
	}
}

